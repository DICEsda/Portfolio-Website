﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinanceTracker.DTO
{
    public class VacationPayDTO
    {
        public decimal VacationPay { get; set; }
    }
}
