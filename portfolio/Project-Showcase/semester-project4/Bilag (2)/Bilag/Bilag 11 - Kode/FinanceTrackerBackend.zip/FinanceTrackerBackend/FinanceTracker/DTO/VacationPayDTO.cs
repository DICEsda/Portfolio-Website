﻿namespace FinanceTracker.DTO
{
    public class VacationPayDTO
    {
        public decimal VacationPay { get; set; }
    }
}
