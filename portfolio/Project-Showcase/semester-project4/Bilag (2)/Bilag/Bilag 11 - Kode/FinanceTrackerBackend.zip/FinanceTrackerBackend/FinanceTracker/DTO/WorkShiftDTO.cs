﻿namespace FinanceTracker.DTO
{
	public class WorkShiftDTO
	{
		public DateTime StartTime { get; set; }

		public DateTime EndTime { get; set; }
	}
}
